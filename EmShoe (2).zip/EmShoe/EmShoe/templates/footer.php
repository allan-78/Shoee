<footer>
    <div class="footer-content">
        <div>
            <h3>About Us</h3>
            <p>We offer a wide selection of high-quality shoes at affordable prices.</p>
        </div>
        <div>
            <h3>Contact Us</h3>
            <p>Email: info@emqualityshoes.com</p>
            <p>Phone: 123-456-7890</p>
        </div>
        <div>
            <h3>Follow Us</h3>
            <p>Facebook | Instagram | Twitter</p>
        </div>
    </div>
    <p>&copy; 2024 EM' Quality Shoes. All rights reserved.</p>
</footer>
