<?php
require_once 'includes/functions/functions.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact | EM' Quality Shoes</title>
    <link rel="stylesheet" href="layout/css/style.css">
</head>
<body>
    <?php include 'templates/header.php'; ?>
    <main>
        <section class="section contact">
            <h2>Contact Us</h2>
            <p>Email: info@emqualityshoes.com</p>
            <p>Phone: 123-456-7890</p>
        </section>
    </main>
    <?php include 'templates/footer.php'; ?>
</body>
</html>
