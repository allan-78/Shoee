<?php
require_once 'includes/functions/functions.php';
session_start();

$products = getProducts();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Products | EM' Quality Shoes</title>
    <link rel="stylesheet" href="layout/css/style.css">
</head>
<body>
    <?php include 'templates/header.php'; ?>
    <main>
        <section class="section products">
            <h2>Products</h2>
            <div class="product-grid">
                <?php foreach ($products as $product): ?>
                    <div class="product-item">
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                        <h3><?php echo $product['name']; ?></h3>
                        <p>$<?php echo number_format($product['price'], 2); ?></p>
                        <a href="item_details.php?id=<?php echo $product['id']; ?>">View Details</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
    <?php include 'templates/footer.php'; ?>
</body>
</html>
