<?php
require_once 'includes/functions/functions.php';
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $address = $_POST['address'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $role = $_POST['role'] ?? '';
   // Check if email already exists
   if (emailExists($email)) {
    $message = "Email already registered. Please use a different email.";
}
// Check if username already exists
elseif (usernameExists($username)) {
    $message = "Username already taken. Please choose a different username.";
} else {
    // Attempt to register the user
    $result = registerUser($username, $password, $email, $firstName, $lastName, $phone, $address);
    $message = $result ? "User registered successfully!" : "Failed to register user. Please try again.";
}

}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="layout/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        main {
            padding: 20px;
        }
        .register {
            background-color: #fff;
            padding: 20px;
            margin: 20px auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
        }
        .register h2 {
            margin-top: 0;
        }
        .register label {
            display: block;
            margin-bottom: 5px;
        }
        .register input, .register select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .register button {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .register button:hover {
            background-color: #555;
        }
        .role-options {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .role-options label {
            flex: 1;
            text-align: center;
        }
        .role-options input {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>EM' Quality Shoes</h1>
        <!-- Navigation -->
    </header>
    <main>
        <section class="register">
            <h2>Register</h2>
            <?php if (!empty($message)): ?>
                <p><?php echo $message; ?></p>
            <?php endif; ?>
            <form method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <label for="first_name">First Name:</label>
                <input type="text" id="first_name" name="first_name" required>

                <label for="last_name">Last Name:</label>
                <input type="text" id="last_name" name="last_name" required>

                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>

                <label for="phone">Phone Number:</label>
                <input type="text" id="phone" name="phone" required>

                <label for="role">Role:</label>
                <div class="role-options">
                    <label>
                        <input type="radio" name="role" value="user" required> User
                    </label>
                    <label>
                        <input type="radio" name="role" value="admin" required> Admin
                    </label>
                </div>

                <button type="submit">Register</button>
            </form>
            <p>Already have an account? <a href="login.php">Login</a></p>
        </section>
    </main>
    <footer>
        <!-- Footer content -->
    </footer>
</body>
</html>
