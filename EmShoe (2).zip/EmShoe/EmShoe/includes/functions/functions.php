<?php
// Database connection
function connectDB() {
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ShoeShop";

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

// Sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// User registration
function registerUser($username, $password, $email, $first_name, $last_name, $phone, $address) {
    $conn = connectDB();

    // Sanitize input
    $username = sanitizeInput($username);
    $password = password_hash($password, PASSWORD_DEFAULT); // Hash password
    $email = sanitizeInput($email);
    $first_name = sanitizeInput($first_name);
    $last_name = sanitizeInput($last_name);
    $phone = sanitizeInput($phone);
    $address = sanitizeInput($address);

    $sql = "INSERT INTO users (username, password, email, first_name, last_name, phone, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $username, $password, $email, $first_name, $last_name, $phone, $address);

    if ($stmt->execute()) {
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

// User login
function loginUser($username, $password) {
    $conn = connectDB();
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_logged_in'] = true;
        $_SESSION['user_id'] = $user['id'];
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

// User logout
function logoutUser() {
    session_start();
    session_destroy();
}

// Function to get all products
function getProducts() {
    $conn = connectDB();
    $sql = "SELECT * FROM products";
    $result = $conn->query($sql);
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $conn->close();
    return $products;
}

// Function to get a product by its ID
function getProductById($product_id) {
    $conn = connectDB();
    $sql = "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $conn->close();
    return $product;
}

// Function to get all categories
function getCategories() {
    $conn = connectDB();
    $sql = "SELECT * FROM categories";
    $result = $conn->query($sql);
    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
    $conn->close();
    return $categories;
}

// Function to get category by ID
function getCategoryById($category_id) {
    $conn = connectDB();
    $sql = "SELECT * FROM categories WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $category = $result->fetch_assoc();
    $conn->close();
    return $category;
}

// Function to get products by category ID
function getProductsByCategoryId($category_id) {
    $conn = connectDB();
    $sql = "SELECT * FROM products WHERE category_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $conn->close();
    return $products;
}

// Function to get all categories (alternative name)
function getAllCategories() {
    return getCategories();
}

// Function to get user details by ID
function getUserDetails($user_id) {
    $conn = connectDB();
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $conn->close();
    return $user;
}

// Function to update user details
function updateUserDetails($user_id, $username, $email, $first_name, $last_name, $phone, $address) {
    $conn = connectDB();

    // Sanitize input
    $username = sanitizeInput($username);
    $email = sanitizeInput($email);
    $first_name = sanitizeInput($first_name);
    $last_name = sanitizeInput($last_name);
    $phone = sanitizeInput($phone);
    $address = sanitizeInput($address);

    $sql = "UPDATE users SET username = ?, email = ?, first_name = ?, last_name = ?, phone = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $username, $email, $first_name, $last_name, $phone, $address, $user_id);

    if ($stmt->execute()) {
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

// Function to get order items by order ID
function getOrderItemsByOrderId($order_id) {
    $conn = connectDB();
    $sql = "SELECT oi.*, p.name AS product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order_items = [];
    while ($row = $result->fetch_assoc()) {
        $order_items[] = $row;
    }
    $conn->close();
    return $order_items;
}
// In functions.php
function emailExists($email) {
    $conn = connectDB(); // Establish the connection here
    $email = sanitizeInput($email); // Make sure to sanitize input

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $conn->close(); // Always close the connection
    return $result->num_rows > 0;
}
function usernameExists($username) {
    $conn = connectDB(); // Establish the connection
    $username = sanitizeInput($username); // Sanitize input

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $conn->close(); // Close connection
    return $result->num_rows > 0; // Returns true if username exists
}
// Add more functions as needed
?>
